import XCTest
@testable import MISHUltraVision

@MainActor final class ClientTests: XCTestCase {
    func testTokenAndFilenameEncoding() throws {
        let client = ServerClient()
        client.address = "http://10.0.0.2:8765"
        client.token = "a+b/?&"
        let file = MediaFile(name: "Кино #1.mp4", id: "1", size: 123)
        let url = try XCTUnwrap(client.mediaURL(file))
        let parts = try XCTUnwrap(URLComponents(url: url, resolvingAgainstBaseURL: false))
        XCTAssertEqual(parts.path, "/media/Кино #1.mp4")
        XCTAssertEqual(parts.queryItems?.first?.value, client.token)
        XCTAssertFalse(parts.percentEncodedQuery!.contains("+"))
    }
    func testRejectAddressWithQuery() {
        let client = ServerClient()
        for address in ["file:///etc/passwd", "http://host?token=x", "http://user:pass@host", "http://host/path"] {
            client.address = address
            XCTAssertNil(client.url("api/status"))
        }
    }
    func testNestedFilenameAndDirectStream() throws {
        let client = ServerClient()
        client.address = "http://10.0.0.2:8765"
        client.token = "test+token"
        let file = MediaFile(name: "Фильмы/Кино #1.mp4", id: "1", size: 200)
        XCTAssertEqual(client.mediaURL(file)?.path, "/media/Фильмы/Кино #1.mp4")
        XCTAssertNotNil(ServerClient.streamURL("https://example.com/video.m3u8"))
        XCTAssertNil(ServerClient.streamURL("file:///etc/passwd"))
        XCTAssertNil(ServerClient.streamURL("javascript:alert(1)"))
    }
    func testCatalogPresentation() throws {
        let data = Data(#"{"name":"Фильмы/Тест.mp4","id":"id","size":42,"title":"Тест","folder":"Фильмы","source":"library"}"#.utf8)
        let file = try JSONDecoder().decode(MediaFile.self, from: data)
        XCTAssertEqual(file.displayTitle, "Тест")
        XCTAssertEqual(file.folderName, "Фильмы")
        XCTAssertEqual(file.sourceID, "library")
    }
}
