import XCTest
@testable import MISHUltraVision

@MainActor final class ClientTests: XCTestCase {
    func testTokenAndFilenameEncoding() throws {
        let client = ServerClient()
        client.address = "http://10.0.0.2:8765"
        client.token = "a+b/?&"
        let file = MediaFile(name: "Кино #1.mp4", id: "1", size: 123)
        let url = try XCTUnwrap(client.mediaURL(file))
        let parts = try XCTUnwrap(URLComponents(url: url, resolvingAgainstBaseURL: false))
        XCTAssertEqual(parts.path, "/media/Кино #1.mp4")
        XCTAssertEqual(parts.queryItems?.first?.value, client.token)
        XCTAssertFalse(parts.percentEncodedQuery!.contains("+"))
    }
    func testRejectAddressWithQuery() {
        let client = ServerClient()
        for address in ["file:///etc/passwd", "http://host?token=x", "http://user:pass@host", "http://host/path"] {
            client.address = address
            XCTAssertNil(client.url("api/status"))
        }
    }
}
