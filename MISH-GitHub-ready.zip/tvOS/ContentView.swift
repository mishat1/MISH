import SwiftUI
import AVKit
import Combine

struct ContentView: View {
    @StateObject private var client = ServerClient()
    @StateObject private var discovery = Discovery()
    @State private var selectedFile: MediaFile?
    @State private var playerURL: URL?
    @State private var mode = "balanced"

    var body: some View {
        TabView {
            VStack(alignment: .leading, spacing: 24) {
                Text("MISH UltraVision 0.6.1").font(.largeTitle)
                Text("Сервер Windows 11 — адрес в домашней сети")
                HStack {
                    TextField("http://192.168.1.100:8765", text: $client.address)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button("Подключить") { Task { await client.connect() } }
                }
                SecureField("Токен из server-token.txt", text: $client.token)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Text(client.serverName)
                Text(client.message).foregroundStyle(.secondary)
                HStack {
                    Button("Найти узлы Bonjour") { discovery.start() }
                    Button("Остановить поиск") { discovery.stop() }
                }
                ForEach(discovery.nodes) { node in
                    Text("Обнаружено: \(node.name) (для подключения укажи IP сервера)")
                }
                Spacer()
            }.padding(45).tabItem { Text("Сеть") }

            VStack(alignment: .leading, spacing: 20) {
                Text("Медиатека").font(.largeTitle)
                Button("Обновить") { Task { await client.refresh() } }
                List(client.files) { file in
                    HStack {
                        Text(file.name)
                        Spacer()
                        Button("Смотреть") { playerURL = client.mediaURL(file) }
                        Button("Выбрать") { selectedFile = file }
                    }
                }
                Picker("Обработка", selection: $mode) {
                    ForEach(client.modes, id: \.self) { availableMode in
                        Text(modeTitle(availableMode)).tag(availableMode)
                    }
                }
                if let file = selectedFile {
                    Button("Обработать: \(file.name)") { Task { await client.process(file, mode: mode) } }
                        .disabled(!client.connected || !client.modes.contains(mode))
                }
                Text("Обработка FFmpeg выполняется на сервере и может занять время. Режимы AI используют Real-ESRGAN NCNN Vulkan при установке движка на Windows.")
                    .font(.caption).foregroundStyle(.secondary)
            }.padding(45).tabItem { Text("Видео") }

            VStack(alignment: .leading, spacing: 18) {
                Text("Задачи").font(.largeTitle)
                Button("Обновить") { Task { await client.refresh() } }
                List(Array(client.jobs.keys.sorted()), id: \.self) { key in
                    if let job = client.jobs[key] {
                        HStack {
                            Text("\(job.name): \(job.status)")
                            if let error = job.error { Text(error).foregroundStyle(.red) }
                            Spacer()
                            if let path = job.url, let url = client.url(String(path.dropFirst())) {
                                Button("Смотреть") { playerURL = url }
                            }
                        }
                    }
                }
            }.padding(45).tabItem { Text("Задачи") }

            VStack(alignment: .leading, spacing: 20) {
                Text("Диагностика Apple TV").font(.largeTitle)
                ForEach(HardwareInfo.rows, id: \.0) { key, value in
                    HStack { Text(key).bold().frame(width: 300, alignment: .leading); Text(value) }
                }
                Spacer()
            }.padding(45).tabItem { Text("Устройство") }
        }
        .task {
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 3_000_000_000) } catch { break }
                if client.connected { await client.refresh() }
            }
        }
        .sheet(item: Binding(
            get: { playerURL.map { PlayableURL(url: $0) } },
            set: { playerURL = $0?.url }
        )) { item in
            PlayerScreen(url: item.url)
        }
    }

    private func modeTitle(_ mode: String) -> String {
        ["clean": "Очистка · FFmpeg", "detail": "Детали · FFmpeg", "balanced": "Баланс · FFmpeg",
         "ai-photo": "Real-ESRGAN x4plus", "ai-anime": "Real-ESRGAN anime", "ai-video": "Real-ESRGAN animevideo v3"][mode] ?? mode
    }
}

struct PlayableURL: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

@MainActor final class PlaybackModel: ObservableObject {
    let player: AVPlayer
    @Published var message = "Загрузка видео…"
    private var observation: NSKeyValueObservation?
    init(url: URL) {
        let item = AVPlayerItem(url: url)
        player = AVPlayer(playerItem: item)
        observation = item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            let state = item.status
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                switch state {
                case .readyToPlay: self.message = ""; self.player.play()
                case .failed: self.message = "Ошибка видео: проверьте сеть, токен и кодек файла"
                default: self.message = "Загрузка видео…"
                }
            }
        }
    }
}

struct PlayerScreen: View {
    @StateObject private var model: PlaybackModel
    init(url: URL) { _model = StateObject(wrappedValue: PlaybackModel(url: url)) }
    var body: some View {
        VStack {
            VideoPlayer(player: model.player)
            if !model.message.isEmpty { Text(model.message) }
        }
        .onDisappear { model.player.pause() }
        .onReceive(NotificationCenter.default.publisher(for: .AVPlayerItemFailedToPlayToEndTime)) { notification in
            if let item = notification.object as? AVPlayerItem, item === model.player.currentItem {
                model.message = "Поток прерван: проверьте сервер и сеть"
            }
        }
    }
}
