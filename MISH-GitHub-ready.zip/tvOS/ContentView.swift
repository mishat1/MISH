import SwiftUI
import AVKit
import Combine

enum MISHTheme {
    static let ink = Color(red: 0.035, green: 0.055, blue: 0.09)
    static let panel = Color(red: 0.075, green: 0.105, blue: 0.15)
    static let mint = Color(red: 0.35, green: 0.91, blue: 0.77)
    static let muted = Color(red: 0.62, green: 0.69, blue: 0.76)
}

struct ContentView: View {
    @StateObject private var client = ServerClient()
    @State private var tab = 0
    @State private var search = ""
    @State private var folder: String?
    @State private var source: String?
    @State private var selected: MediaFile?
    @State private var stream = ""
    @State private var playing: PlayableURL?
    @AppStorage("favoriteMedia") private var favoritesJSON = "[]"
    @State private var onlyFavorites = false

    private var favorites: Set<String> {
        Set((try? JSONDecoder().decode([String].self, from: Data(favoritesJSON.utf8))) ?? [])
    }
    private var filteredFiles: [MediaFile] {
        client.files.filter {
            (search.isEmpty || $0.displayTitle.localizedCaseInsensitiveContains(search)) &&
            (folder == nil || $0.folderName == folder) && (source == nil || $0.sourceID == source) &&
            (!onlyFavorites || favorites.contains($0.id))
        }
    }
    private var folders: [String] { Array(Set(client.files.map(\.folderName))).sorted() }
    private var aiCount: Int { client.modes.filter { $0.hasPrefix("ai-") }.count }

    var body: some View {
        TabView(selection: $tab) {
            home.tabItem { Label("Главная", systemImage: "house.fill") }.tag(0)
            library.tabItem { Label("Фильмы", systemImage: "film") }.tag(1)
            folderView.tabItem { Label("Папки", systemImage: "folder") }.tag(2)
            sourcesView.tabItem { Label("Источники", systemImage: "square.stack.3d.up") }.tag(3)
            jobsView.tabItem { Label("Обработка", systemImage: "sparkles") }.tag(4)
            connection.tabItem { Label("Компьютер", systemImage: "desktopcomputer") }.tag(5)
        }
        .tint(MISHTheme.mint)
        .preferredColorScheme(.dark)
        .sheet(item: $selected) { file in
            MediaDetail(file: file, client: client, isFavorite: favorites.contains(file.id),
                toggleFavorite: { toggleFavorite(file.id) })
        }
        .fullScreenCover(item: $playing) { PlayerScreen(url: $0.url, resumeKey: nil) }
        .task {
            let args = ProcessInfo.processInfo.arguments
            if let i = args.firstIndex(of: "--mish-tab"), args.count > i + 1, let number = Int(args[i + 1]) { tab = number }
            if !client.token.isEmpty { await client.connect() }
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 5_000_000_000) } catch { break }
                if client.connected && !client.busy { await client.refresh() }
            }
        }
    }

    private var home: some View {
        page {
            HStack(alignment: .center, spacing: 60) {
                VStack(alignment: .leading, spacing: 18) {
                    Text("ВАШ ДОМАШНИЙ КИНОЗАЛ").font(.caption.weight(.semibold)).tracking(5).foregroundStyle(MISHTheme.mint)
                    Text("Всё кино.\nВ одном месте.").font(.system(size: 64, weight: .bold, design: .rounded))
                    Text("Фильмы с компьютера, любимые папки\nи обработка видео — на большом экране.")
                        .font(.title3).foregroundStyle(MISHTheme.muted)
                    HStack(spacing: 20) {
                        Label(client.connected ? "Компьютер подключён" : "Подключите компьютер",
                              systemImage: client.connected ? "checkmark.circle.fill" : "circle.dashed")
                            .foregroundStyle(client.connected ? MISHTheme.mint : .white)
                        if client.connected { Text("\(client.files.count) видео · \(client.sources.count) источников").foregroundStyle(MISHTheme.muted) }
                    }.font(.caption)
                }
                Spacer()
                Image("BrandMark").resizable().scaledToFit().frame(width: 390, height: 234)
                    .clipShape(RoundedRectangle(cornerRadius: 28))
            }.padding(.vertical, 24)
            HStack(spacing: 30) {
                HomeTile(title: "Мои фильмы", subtitle: "Каталог и поиск", icon: "play.rectangle.fill") { folder = nil; source = nil; tab = 1 }
                HomeTile(title: "Папки", subtitle: "Знакомая структура", icon: "folder.fill") { tab = 2 }
                HomeTile(title: "Источники", subtitle: "Компьютер и ссылки", icon: "externaldrive.connected.to.line.below.fill") { tab = 3 }
                HomeTile(title: "Обработка", subtitle: aiCount > 0 ? "\(aiCount) проверенных AI-моделей" : "Состояние задач", icon: "sparkles") { tab = 4 }
            }
            if !client.connected {
                HStack {
                    Text("Начните с подключения Windows-сервера").font(.headline)
                    Spacer()
                    Button("Подключить компьютер") { tab = 5 }
                }.padding(28).background(MISHTheme.panel, in: RoundedRectangle(cornerRadius: 20))
            }
        }
    }

    private var library: some View {
        page {
            sectionHeader("Мои фильмы", subtitle: "\(filteredFiles.count) видео в выбранной коллекции")
            HStack(spacing: 24) {
                TextField("Найти фильм по названию", text: $search)
                Button(onlyFavorites ? "Все фильмы" : "Избранное") { onlyFavorites.toggle() }
                Button("Все папки") { folder = nil; source = nil }
                Button("Обновить") { Task { await client.refresh() } }.disabled(!client.connected)
            }
            if let folder { Text("Папка: \(folder.isEmpty ? "Корень медиатеки" : folder)").foregroundStyle(MISHTheme.mint) }
            if filteredFiles.isEmpty {
                EmptyPanel(icon: "film.stack", title: client.connected ? "Здесь пока нет видео" : "Нужен компьютер с MISH",
                    text: client.connected ? "Добавьте фильмы в выбранную папку на Windows или измените фильтр." : "Откройте вкладку «Компьютер» и подключите свой сервер.")
            } else {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 34) {
                    ForEach(filteredFiles) { file in
                        Button { selected = file } label: {
                            VStack(alignment: .leading, spacing: 12) {
                                MovieImage(url: client.thumbnailURL(file)).frame(height: 190).clipped()
                                Text(file.displayTitle).font(.headline).lineLimit(2).foregroundStyle(.white)
                                HStack {
                                    Text(ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file))
                                    Spacer()
                                    if favorites.contains(file.id) { Image(systemName: "heart.fill").foregroundStyle(MISHTheme.mint) }
                                }.font(.caption).foregroundStyle(MISHTheme.muted)
                            }.padding(16).background(MISHTheme.panel, in: RoundedRectangle(cornerRadius: 20))
                        }.buttonStyle(.card).accessibilityIdentifier("movie.\(file.id)")
                    }
                }.padding(.top, 10)
            }
        }
    }

    private var folderView: some View {
        page {
            sectionHeader("Ваши папки", subtitle: "Структура каталогов, которыми поделился компьютер")
            if folders.isEmpty { EmptyPanel(icon: "folder", title: "Папки появятся после подключения", text: "Сервер показывает только выбранные вами источники.") }
            ForEach(folders, id: \.self) { value in
                Button { folder = value; source = nil; tab = 1 } label: {
                    HStack(spacing: 28) {
                        Image(systemName: "folder.fill").font(.system(size: 38)).foregroundStyle(MISHTheme.mint)
                        VStack(alignment: .leading, spacing: 6) {
                            Text(value.isEmpty ? "Корень медиатеки" : value).font(.headline)
                            Text("\(client.files.filter { $0.folderName == value }.count) видео").font(.caption).foregroundStyle(MISHTheme.muted)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                    }.padding(24)
                }.buttonStyle(.card)
            }
        }
    }

    private var sourcesView: some View {
        page {
            sectionHeader("Откуда приходит кино", subtitle: "Ваш компьютер, выбранные каталоги и прямые видеопотоки")
            ForEach(client.sources) { item in
                Button { source = item.id; folder = nil; tab = 1 } label: {
                    HStack(spacing: 24) {
                        Image(systemName: "externaldrive.fill").font(.largeTitle).foregroundStyle(MISHTheme.mint)
                        VStack(alignment: .leading) { Text(item.title).font(.headline); Text("\(item.count) видео · Windows").font(.caption).foregroundStyle(MISHTheme.muted) }
                        Spacer(); Image(systemName: "chevron.right")
                    }.padding(24)
                }.buttonStyle(.card)
            }
            VStack(alignment: .leading, spacing: 22) {
                Label("Видео по ссылке", systemImage: "link").font(.title2.bold())
                Text("Прямая ссылка на MP4 или HLS-поток. Воспроизведение зависит от формата и доступа к источнику.")
                    .foregroundStyle(MISHTheme.muted)
                TextField("https://…/video.mp4 или playlist.m3u8", text: $stream)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("Открыть видео") { if let url = ServerClient.streamURL(stream) { playing = PlayableURL(url: url) } }
                    .disabled(ServerClient.streamURL(stream) == nil)
                Text("Обычная страница сайта — не видеоссылка. Панель в браузере компьютера открывается по адресу сервера.")
                    .font(.caption).foregroundStyle(MISHTheme.muted)
            }.padding(32).background(MISHTheme.panel, in: RoundedRectangle(cornerRadius: 24))
        }
    }

    private var jobsView: some View {
        page {
            sectionHeader("Мастерская видео", subtitle: "Обработка выполняется на Windows. Готовые файлы появятся здесь.")
            HStack(spacing: 20) {
                Label(aiCount > 0 ? "AI-моделей проверено: \(aiCount)" : "AI не проверен сервером", systemImage: "sparkles")
                    .foregroundStyle(aiCount > 0 ? MISHTheme.mint : MISHTheme.muted)
                Spacer()
                Button("Обновить задачи") { Task { await client.refresh() } }.disabled(!client.connected)
            }
            if client.jobs.isEmpty { EmptyPanel(icon: "wand.and.stars", title: "Выберите фильм для обработки", text: "Откройте карточку фильма. Там можно выбрать один из доступных на сервере режимов.") }
            ForEach(client.jobs.keys.sorted(), id: \.self) { key in
                if let job = client.jobs[key] {
                    VStack(alignment: .leading, spacing: 16) {
                        HStack { Text(URL(fileURLWithPath: job.name).lastPathComponent).font(.headline); Spacer(); Text(jobTitle(job.status)).foregroundStyle(MISHTheme.mint) }
                        Text(modeTitle(job.mode)).font(.caption).foregroundStyle(MISHTheme.muted)
                        if job.status == "processing" { ProgressView() }
                        if let error = job.error { Text(error).font(.caption).foregroundStyle(.orange) }
                        if job.status == "ready", let path = job.url, let url = client.url(String(path.dropFirst())) {
                            Button("Смотреть результат") { playing = PlayableURL(url: url) }
                        }
                    }.padding(28).background(MISHTheme.panel, in: RoundedRectangle(cornerRadius: 22))
                }
            }
        }
    }

    private var connection: some View {
        page {
            sectionHeader("Ваш компьютер", subtitle: "Один раз подключите Windows — и возвращайтесь к своему кино")
            VStack(alignment: .leading, spacing: 24) {
                Label(client.serverName, systemImage: "desktopcomputer").font(.title2.bold())
                TextField("Адрес Windows, например http://10.0.0.2:8765", text: $client.address)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                SecureField("Код доступа из окна сервера", text: $client.token)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                HStack {
                    Button(client.busy ? "Подключение…" : "Подключить") { Task { await client.connect() } }
                        .disabled(client.busy || client.token.isEmpty)
                    if client.busy { ProgressView() }
                }
                Text(client.message.isEmpty ? "Запустите MISH на Windows. Компьютер и Apple TV должны быть в одной сети." : client.message)
                    .foregroundStyle(MISHTheme.muted)
                Text("Адрес сохраняется на Apple TV, код доступа — в защищённой связке ключей.")
                    .font(.caption).foregroundStyle(MISHTheme.muted)
            }.padding(34).background(MISHTheme.panel, in: RoundedRectangle(cornerRadius: 26))
            HStack(spacing: 40) {
                Label("Windows обрабатывает видео", systemImage: "cpu")
                Label("Apple TV воспроизводит", systemImage: "appletv.fill")
                Label("Фильмы остаются у вас", systemImage: "externaldrive")
            }.font(.caption).foregroundStyle(MISHTheme.muted)
        }
    }

    private func page<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30, content: content).padding(.horizontal, 70).padding(.top, 35).padding(.bottom, 70)
        }.background(LinearGradient(colors: [MISHTheme.ink, Color(red: 0.025, green: 0.08, blue: 0.105)], startPoint: .topLeading, endPoint: .bottomTrailing))
    }
    private func sectionHeader(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(.system(size: 46, weight: .bold, design: .rounded))
            Text(subtitle).font(.title3).foregroundStyle(MISHTheme.muted)
        }.padding(.bottom, 8)
    }
    private func toggleFavorite(_ id: String) {
        var values = favorites
        if values.contains(id) { values.remove(id) } else { values.insert(id) }
        favoritesJSON = String(data: (try? JSONEncoder().encode(Array(values))) ?? Data("[]".utf8), encoding: .utf8) ?? "[]"
    }
}

struct HomeTile: View {
    let title: String
    let subtitle: String
    let icon: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 14) {
                Image(systemName: icon).font(.system(size: 36)).foregroundStyle(MISHTheme.mint)
                Text(title).font(.title3.bold()).foregroundStyle(.white)
                Text(subtitle).font(.caption).foregroundStyle(MISHTheme.muted)
            }.frame(maxWidth: .infinity, minHeight: 155, alignment: .leading).padding(24)
                .background(MISHTheme.panel, in: RoundedRectangle(cornerRadius: 22))
        }.buttonStyle(.card)
    }
}

struct EmptyPanel: View {
    let icon: String
    let title: String
    let text: String
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: icon).font(.system(size: 50)).foregroundStyle(MISHTheme.mint)
            Text(title).font(.title2.bold())
            Text(text).multilineTextAlignment(.center).foregroundStyle(MISHTheme.muted)
        }.frame(maxWidth: .infinity).padding(65).background(MISHTheme.panel, in: RoundedRectangle(cornerRadius: 26))
    }
}

struct MovieImage: View {
    let url: URL?
    var body: some View {
        AsyncImage(url: url) { image in image.resizable().scaledToFill() } placeholder: {
            ZStack { MISHTheme.ink; Image(systemName: "film").font(.largeTitle).foregroundStyle(MISHTheme.muted) }
        }.clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct MediaDetail: View {
    let file: MediaFile
    @ObservedObject var client: ServerClient
    let isFavorite: Bool
    let toggleFavorite: () -> Void
    @State private var mode = "balanced"
    @State private var playing: PlayableURL?
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                MovieImage(url: client.thumbnailURL(file)).frame(height: 330).clipped()
                Text(file.displayTitle).font(.largeTitle.bold())
                Text("\(file.folderName.isEmpty ? "Корень медиатеки" : file.folderName) · \(ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file))")
                    .foregroundStyle(MISHTheme.muted)
                HStack {
                    Button("Смотреть / продолжить") { if let url = client.mediaURL(file) { playing = PlayableURL(url: url) } }
                    Button(isFavorite ? "Убрать из избранного" : "В избранное", action: toggleFavorite)
                }
                if !client.modes.isEmpty {
                    Divider()
                    Text("Подготовить улучшенную копию").font(.title2.bold())
                    Picker("Режим обработки", selection: $mode) {
                        ForEach(client.modes, id: \.self) { Text(modeTitle($0)).tag($0) }
                    }
                    Button("Начать обработку на компьютере") { Task { await client.process(file, mode: mode) } }
                        .disabled(!client.modes.contains(mode))
                    Text("Оригинал сохраняется. Результат будет во вкладке «Обработка». Это предварительная обработка SDR; она может занять время.")
                        .font(.caption).foregroundStyle(MISHTheme.muted)
                }
                Text(client.message).font(.caption).foregroundStyle(MISHTheme.mint)
            }.padding(55)
        }.background(MISHTheme.ink)
        .fullScreenCover(item: $playing) { PlayerScreen(url: $0.url, resumeKey: file.id) }
    }
}

func modeTitle(_ mode: String) -> String {
    ["clean": "Очистка · FFmpeg", "detail": "Детали · FFmpeg", "balanced": "Баланс · FFmpeg",
     "ai-photo": "AI · Real-ESRGAN x4plus", "ai-anime": "AI · Аниме", "ai-video": "AI · Анимационное видео"][mode] ?? mode
}
func jobTitle(_ status: String) -> String {
    ["queued": "В очереди", "processing": "Обрабатывается", "ready": "Готово", "error": "Ошибка"][status] ?? status
}

struct PlayableURL: Identifiable { let url: URL; var id: String { url.absoluteString } }

@MainActor final class PlaybackModel: ObservableObject {
    let player: AVPlayer
    let resumeKey: String?
    @Published var message = "Загрузка видео…"
    private var observation: NSKeyValueObservation?
    private var timer: Any?
    init(url: URL, resumeKey: String?) {
        self.resumeKey = resumeKey
        let item = AVPlayerItem(url: url)
        player = AVPlayer(playerItem: item)
        observation = item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            let state = item.status
            Task { @MainActor [weak self] in
                guard let self else { return }
                switch state {
                case .readyToPlay:
                    self.message = ""
                    if let key = self.resumeKey {
                        let time = UserDefaults.standard.double(forKey: "progress." + key)
                        if time > 5 { self.player.seek(to: CMTime(seconds: time, preferredTimescale: 600)) }
                    }
                    self.player.play()
                case .failed: self.message = "Не удалось открыть видео. Проверьте источник, сеть и формат файла."
                default: break
                }
            }
        }
        timer = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 5, preferredTimescale: 1), queue: .main) { [weak self] time in
            Task { @MainActor [weak self] in self?.save(time.seconds) }
        }
    }
    func save(_ seconds: Double) {
        guard let resumeKey, seconds.isFinite, seconds >= 0 else { return }
        let duration = player.currentItem?.duration.seconds ?? .nan
        let position = duration.isFinite && duration - seconds < 10 ? 0 : seconds
        UserDefaults.standard.set(position, forKey: "progress." + resumeKey)
    }
    func stop() {
        save(player.currentTime().seconds)
        player.pause()
        if let timer { player.removeTimeObserver(timer); self.timer = nil }
    }
}

struct PlayerScreen: View {
    @StateObject private var model: PlaybackModel
    init(url: URL, resumeKey: String?) { _model = StateObject(wrappedValue: PlaybackModel(url: url, resumeKey: resumeKey)) }
    var body: some View {
        VStack { VideoPlayer(player: model.player); if !model.message.isEmpty { Text(model.message).padding() } }
            .background(.black).onDisappear { model.stop() }
            .onReceive(NotificationCenter.default.publisher(for: .AVPlayerItemFailedToPlayToEndTime)) { note in
                if let item = note.object as? AVPlayerItem, item === model.player.currentItem { model.message = "Поток прерван. Проверьте компьютер и сеть." }
            }
    }
}
