import Foundation
import Network
import Combine

struct DiscoveredNode: Identifiable, Hashable {
    let id: String
    let name: String
    let host: String
    let port: Int
}

@MainActor
final class Discovery: ObservableObject {
    @Published var nodes: [DiscoveredNode] = []
    @Published var scanning = false
    private var browser: NWBrowser?
    private let queue = DispatchQueue(label: "mish.discovery")

    func start() {
        stop()
        scanning = true
        let params = NWParameters.tcp
        params.includePeerToPeer = false
        let b = NWBrowser(for: .bonjour(type: "_mishvision._tcp", domain: nil), using: params)
        browser = b
        b.browseResultsChangedHandler = { [weak self] results, _ in
            let mapped: [DiscoveredNode] = results.compactMap { result in
                guard case let .service(name, type, domain, _) = result.endpoint else { return nil }
                return DiscoveredNode(id: "\(name).\(type).\(domain)", name: name, host: "", port: 0)
            }
            Task { @MainActor in self?.nodes = mapped }
        }
        b.stateUpdateHandler = { [weak self] state in
            if case .failed = state { Task { @MainActor in self?.scanning = false } }
        }
        b.start(queue: queue)
    }

    func stop() {
        browser?.cancel(); browser = nil; scanning = false
    }
}
