import Foundation
import Metal

struct HardwareInfo {
    static var rows: [(String,String)] {
        let os = ProcessInfo.processInfo.operatingSystemVersionString
        let gpu = MTLCreateSystemDefaultDevice()
        return [
            ("Система", os),
            ("Metal GPU", gpu?.name ?? "Не найден"),
            ("Metal доступен", gpu == nil ? "Нет" : "Да"),
            ("GPU registryID", gpu.map { String($0.registryID) } ?? "—"),
            ("Core ML", "Бенчмарк нейросети ещё не реализован"),
            ("AI Upscaling", "Проверенные сервером модели появляются в списке обработки")
        ]
    }
}
