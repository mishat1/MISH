import SwiftUI

@main
struct MISHUltraVisionApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
