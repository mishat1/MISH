#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
command -v xcodegen >/dev/null
command -v xcodebuild >/dev/null
xcodegen generate
xcodebuild -project MISHUltraVision.xcodeproj -scheme MISHUltraVision \
  -configuration Release -sdk appletvos -destination 'generic/platform=tvOS' \
  -derivedDataPath build CODE_SIGNING_ALLOWED=NO build
mkdir -p build/package/Payload
ditto build/Build/Products/Release-appletvos/MISHUltraVision.app \
  build/package/Payload/MISHUltraVision.app
ditto -c -k --keepParent build/package/Payload build/MISHUltraVision-UNSIGNED.ipa
echo 'Unsigned IPA: build/MISHUltraVision-UNSIGNED.ipa — sign before installing.'
