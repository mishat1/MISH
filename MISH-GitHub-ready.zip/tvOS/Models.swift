import Foundation

struct MediaFile: Codable, Identifiable {
    let name: String
    let id: String
    let size: Int64
}

struct ServerStatus: Codable {
    let name: String
    let version: String
    let features: [String]
    let ai_upscaling: Bool
    let modes: [String]
}

struct ProcessRequest: Encodable {
    let name: String
    let mode: String
}

struct ProcessReply: Decodable {
    let job_id: String
}

struct JobStatus: Decodable {
    let status: String
    let name: String
    let mode: String
    let url: String?
    let error: String?
}
