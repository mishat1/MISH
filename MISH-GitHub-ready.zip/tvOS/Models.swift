import Foundation

struct MediaFile: Codable, Identifiable {
    let name: String
    let id: String
    let size: Int64
    var title: String? = nil
    var folder: String? = nil
    var source: String? = nil
    var filename: String? = nil
    var displayTitle: String { title ?? URL(fileURLWithPath: name).deletingPathExtension().lastPathComponent }
    var folderName: String { folder ?? "" }
    var sourceID: String { source ?? "library" }
}

struct MediaSource: Codable, Identifiable {
    let id: String
    let title: String
    let count: Int
}

struct ServerStatus: Codable {
    let name: String
    let version: String
    let features: [String]
    let ai_upscaling: Bool
    let modes: [String]
}

struct ProcessRequest: Encodable {
    let name: String
    let mode: String
}

struct ProcessReply: Decodable {
    let job_id: String
}

struct JobStatus: Decodable {
    let status: String
    let name: String
    let mode: String
    let url: String?
    let error: String?
}
