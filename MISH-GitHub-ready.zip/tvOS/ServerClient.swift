import Foundation
import Combine

@MainActor
final class ServerClient: ObservableObject {
    @Published var address = "http://192.168.1.100:8765"
    @Published var token = ""
    @Published var modes: [String] = []
    @Published var sources: [MediaSource] = []
    @Published var busy = false
    @Published var connected = false
    @Published var serverName = "Не подключено"
    @Published var files: [MediaFile] = []
    @Published var jobs: [String: JobStatus] = [:]
    @Published var message = ""

    init() {
        address = UserDefaults.standard.string(forKey: "serverAddress") ?? "http://10.0.0.2:8765"
        token = Credentials.load(for: address)
        let args = ProcessInfo.processInfo.arguments
        if let i = args.firstIndex(of: "--mish-preview"), args.count > i + 2 {
            address = args[i + 1]; token = args[i + 2]
        }
    }

    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 10
        config.timeoutIntervalForResource = 20
        return URLSession(configuration: config)
    }()

    private var base: URL? {
        guard let url = URL(string: address.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme == "http" || url.scheme == "https", url.host != nil,
              url.user == nil, url.password == nil, url.query == nil, url.fragment == nil,
              url.path.isEmpty || url.path == "/" else { return nil }
        return url
    }

    func url(_ path: String) -> URL? {
        guard let url = base?.appendingPathComponent(path),
              var parts = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        parts.queryItems = [URLQueryItem(name: "token", value: token)]
        parts.percentEncodedQuery = parts.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        return parts.url
    }

    func mediaURL(_ file: MediaFile) -> URL? {
        url("media/" + file.name)
    }

    func thumbnailURL(_ file: MediaFile) -> URL? { url("thumb/" + file.name) }

    static func streamURL(_ text: String) -> URL? {
        guard let url = URL(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              ["http", "https"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else { return nil }
        return url
    }

    func connect() async {
        guard !busy else { return }
        busy = true
        defer { busy = false }
        connected = false; files = []; jobs = [:]; modes = []
        guard let url = url("api/status") else { message = "Неверный адрес"; return }
        do {
            var request = URLRequest(url: url)
            request.timeoutInterval = 5
            let (data, response) = try await session.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            let status = try JSONDecoder().decode(ServerStatus.self, from: data)
            modes = status.modes
            UserDefaults.standard.set(address, forKey: "serverAddress")
            if !ProcessInfo.processInfo.arguments.contains("--mish-preview") { Credentials.save(token, for: address) }
            connected = true; serverName = "\(status.name) v\(status.version)"; message = "Соединение установлено"
            await refresh()
        } catch {
            connected = false; files = []; message = "Ошибка: \(error.localizedDescription)"
        }
    }

    func refresh() async {
        guard let media = url("api/media"), let jobsURL = url("api/jobs") else { return }
        do {
            let (data, mediaResponse) = try await session.data(from: media)
            guard (mediaResponse as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            let newFiles = try JSONDecoder().decode([MediaFile].self, from: data)
            let (jobsData, jobsResponse) = try await session.data(from: jobsURL)
            guard (jobsResponse as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            let newJobs = try JSONDecoder().decode([String: JobStatus].self, from: jobsData)
            files = newFiles; jobs = newJobs
            if let sourcesURL = url("api/sources"),
               let (sourceData, response) = try? await session.data(from: sourcesURL),
               (response as? HTTPURLResponse)?.statusCode == 200,
               let result = try? JSONDecoder().decode([MediaSource].self, from: sourceData) {
                sources = result
            } else { sources = [MediaSource(id: "library", title: "Моя медиатека", count: files.count)] }
            message = "Каталог и задачи обновлены"
        } catch { files = []; jobs = [:]; connected = false; message = "Ошибка обновления: \(error.localizedDescription)" }
    }

    func process(_ file: MediaFile, mode: String) async {
        guard modes.contains(mode) else { message = "Режим недоступен на сервере"; return }
        guard let url = url("api/process") else { return }
        do {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONEncoder().encode(ProcessRequest(name: file.name, mode: mode))
            let (data, response) = try await session.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 202 else { throw URLError(.badServerResponse) }
            let reply = try JSONDecoder().decode(ProcessReply.self, from: data)
            message = "Обработка запущена: \(reply.job_id.prefix(8))"
            await refresh()
        } catch { message = "Не удалось запустить: \(error.localizedDescription)" }
    }
}
