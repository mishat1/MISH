import Foundation
import Combine

@MainActor
final class ServerClient: ObservableObject {
    @Published var address = "http://192.168.1.100:8765"
    @Published var token = ""
    @Published var modes: [String] = []
    @Published var connected = false
    @Published var serverName = "Не подключено"
    @Published var files: [MediaFile] = []
    @Published var jobs: [String: JobStatus] = [:]
    @Published var message = ""

    private var base: URL? {
        guard let url = URL(string: address.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme == "http" || url.scheme == "https", url.host != nil,
              url.user == nil, url.password == nil, url.query == nil, url.fragment == nil,
              url.path.isEmpty || url.path == "/" else { return nil }
        return url
    }

    func url(_ path: String) -> URL? {
        guard let url = base?.appendingPathComponent(path),
              var parts = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        parts.queryItems = [URLQueryItem(name: "token", value: token)]
        parts.percentEncodedQuery = parts.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        return parts.url
    }

    func mediaURL(_ file: MediaFile) -> URL? {
        url("media/" + file.name)
    }

    func connect() async {
        connected = false; files = []; jobs = [:]; modes = []
        guard let url = url("api/status") else { message = "Неверный адрес"; return }
        do {
            var request = URLRequest(url: url)
            request.timeoutInterval = 5
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            let status = try JSONDecoder().decode(ServerStatus.self, from: data)
            modes = status.modes
            connected = true; serverName = "\(status.name) v\(status.version)"; message = "Соединение установлено"
            await refresh()
        } catch {
            connected = false; files = []; message = "Ошибка: \(error.localizedDescription)"
        }
    }

    func refresh() async {
        guard let media = url("api/media"), let jobsURL = url("api/jobs") else { return }
        do {
            let (data, mediaResponse) = try await URLSession.shared.data(from: media)
            guard (mediaResponse as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            let newFiles = try JSONDecoder().decode([MediaFile].self, from: data)
            let (jobsData, jobsResponse) = try await URLSession.shared.data(from: jobsURL)
            guard (jobsResponse as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            let newJobs = try JSONDecoder().decode([String: JobStatus].self, from: jobsData)
            files = newFiles; jobs = newJobs
            message = "Каталог и задачи обновлены"
        } catch { files = []; jobs = [:]; connected = false; message = "Ошибка обновления: \(error.localizedDescription)" }
    }

    func process(_ file: MediaFile, mode: String) async {
        guard modes.contains(mode) else { message = "Режим недоступен на сервере"; return }
        guard let url = url("api/process") else { return }
        do {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONEncoder().encode(ProcessRequest(name: file.name, mode: mode))
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 202 else { throw URLError(.badServerResponse) }
            let reply = try JSONDecoder().decode(ProcessReply.self, from: data)
            message = "Обработка запущена: \(reply.job_id.prefix(8))"
            await refresh()
        } catch { message = "Не удалось запустить: \(error.localizedDescription)" }
    }
}
