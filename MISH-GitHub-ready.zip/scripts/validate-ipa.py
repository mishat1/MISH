"""Validate a real device IPA package; does not validate signature or playback."""
import hashlib
import json
from pathlib import Path
import plistlib
import struct
import sys
import zipfile

def validate(path):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError('Damaged ZIP')
        info_files = [name for name in archive.namelist()
                      if name.startswith('Payload/') and name.count('/') == 2 and name.endswith('.app/Info.plist')]
        if len(info_files) != 1:
            raise ValueError('Expected one Payload/*.app/Info.plist')
        info = plistlib.loads(archive.read(info_files[0]))
        if info.get('CFBundleSupportedPlatforms') != ['AppleTVOS']:
            raise ValueError('Not an Apple TV device build')
        if 3 not in info.get('UIDeviceFamily', []):
            raise ValueError('Apple TV device family missing')
        version = tuple(int(part) for part in info.get('MinimumOSVersion', '999').split('.'))
        if version > (18, 6):
            raise ValueError('Minimum OS excludes tvOS 18.6')
        name = info.get('CFBundleExecutable', '')
        if not name or '/' in name or '\\' in name:
            raise ValueError('Invalid executable name')
        executable = archive.read(info_files[0].rsplit('/', 1)[0] + '/' + name)
        # Generic tvOS device builds target arm64. Reject simulator x86/arm64 platform via plist above.
        if len(executable) < 32 or executable[:4] != b'\xcf\xfa\xed\xfe':
            raise ValueError('Expected a real 64-bit Mach-O executable')
        if struct.unpack_from('<I', executable, 4)[0] != 0x0100000C:
            raise ValueError('Expected ARM64 device executable')
    return {'platform': 'AppleTVOS', 'architecture': 'arm64',
            'minimum_os': info['MinimumOSVersion'], 'bundle_id': info['CFBundleIdentifier'],
            'version': info['CFBundleShortVersionString'],
            'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            'signature': 'Not validated: unsigned artifact requires signing for the device',
            'device_playback': 'Not tested'}

if __name__ == '__main__':
    print(json.dumps(validate(sys.argv[1]), indent=2))
