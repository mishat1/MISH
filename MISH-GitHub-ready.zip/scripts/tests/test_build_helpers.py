import importlib.util
from pathlib import Path
import plistlib
import struct
import tempfile
import unittest
import zipfile

SCRIPTS = Path(__file__).resolve().parents[1]

def module(filename):
    spec = importlib.util.spec_from_file_location(filename, SCRIPTS / (filename + '.py'))
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

select = module('select-tvos-simulator').select
validate = module('validate-ipa').validate

class Helpers(unittest.TestCase):
    def test_select_only_available_tvos(self):
        data = {'devices': {
            'com.apple.CoreSimulator.SimRuntime.iOS-26-0': [{'isAvailable': True, 'udid': 'ios'}],
            'com.apple.CoreSimulator.SimRuntime.tvOS-18-0': [{'isAvailable': True, 'udid': 'old'}],
            'com.apple.CoreSimulator.SimRuntime.tvOS-18-5': [{'isAvailable': True, 'udid': 'tv'}],
            'com.apple.CoreSimulator.SimRuntime.tvOS-26-0': [{'isAvailable': False, 'udid': 'missing'}]}}
        self.assertEqual(select(data), 'tv')

    def test_no_simulator_fails(self):
        with self.assertRaises(RuntimeError):
            select({'devices': {}})

    def package(self, root, platform='AppleTVOS', cpu=0x0100000C, minimum='18.0'):
        # Synthetic validator fixture, never a build artifact or a working app.
        path = root / 'fixture.zip'
        info = {'CFBundleSupportedPlatforms': [platform], 'UIDeviceFamily': [3],
                'MinimumOSVersion': minimum, 'CFBundleExecutable': 'Fixture',
                'CFBundleIdentifier': 'test.fixture', 'CFBundleShortVersionString': '0'}
        header = b'\xcf\xfa\xed\xfe' + struct.pack('<I', cpu) + bytes(24)
        with zipfile.ZipFile(path, 'w') as archive:
            archive.writestr('Payload/Fixture.app/Info.plist', plistlib.dumps(info))
            archive.writestr('Payload/Fixture.app/Fixture', header)
        return path

    def test_device_metadata(self):
        with tempfile.TemporaryDirectory() as folder:
            result = validate(self.package(Path(folder)))
            self.assertEqual(result['platform'], 'AppleTVOS')
            self.assertEqual(result['minimum_os'], '18.0')

    def test_reject_simulator_and_wrong_cpu(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with self.assertRaisesRegex(ValueError, 'device build'):
                validate(self.package(root, platform='AppleTVSimulator'))
            with self.assertRaisesRegex(ValueError, 'ARM64'):
                validate(self.package(root, cpu=0x01000007))

    def test_reject_higher_minimum_os(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(ValueError, 'excludes'):
                validate(self.package(Path(folder), minimum='26.0'))

if __name__ == '__main__':
    unittest.main(verbosity=2)
