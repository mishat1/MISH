"""Select a bootable tvOS simulator from simctl JSON, or fail explicitly."""
import json
from pathlib import Path
import re
import sys

def select(data):
    candidates = []
    for runtime, devices in data.get('devices', {}).items():
        match = re.search(r'\.tvOS-(\d+(?:-\d+)*)$', runtime)
        if not match:
            continue
        version = tuple(int(part) for part in match[1].split('-'))
        if version < (18, 0):
            continue
        for device in devices:
            if device.get('isAvailable') and device.get('udid'):
                candidates.append((version, device['udid']))
    if not candidates:
        raise RuntimeError('No available tvOS 18+ simulator. See artifacts/simulators.json.')
    return max(candidates)[1]

if __name__ == '__main__':
    print(select(json.loads(Path(sys.argv[1]).read_text())))
