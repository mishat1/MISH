# Downloads tested upstream archives into this project; installs nothing globally.
$ErrorActionPreference = 'Stop'
$manifest = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'tools-manifest.json') | ConvertFrom-Json
$toolsRoot = Join-Path $PSScriptRoot 'tools'
New-Item -ItemType Directory -Path $toolsRoot -Force | Out-Null
foreach ($entry in $manifest.tools) {
    $archive = Join-Path $toolsRoot ($entry.name + '.zip')
    if (-not (Test-Path -LiteralPath $archive)) {
        Invoke-WebRequest -Uri $entry.url -OutFile $archive
    }
    $actual = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $entry.sha256) {
        throw "Checksum mismatch for $($entry.name). Upstream may have changed; do not run this file."
    }
    $destination = Join-Path $toolsRoot $entry.name
    if (-not (Test-Path -LiteralPath $destination)) {
        Expand-Archive -LiteralPath $archive -DestinationPath $destination
    }
    Write-Host "Verified and extracted: $($entry.name)"
}
Write-Host 'Next: .\Start-Windows.ps1 -VerifyAI'
