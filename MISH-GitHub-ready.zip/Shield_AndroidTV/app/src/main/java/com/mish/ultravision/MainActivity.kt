package com.mish.ultravision

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var files: LinearLayout
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,24,28,20) }
        val scroll = ScrollView(this).apply { addView(root) }; setContentView(scroll)
        root.addView(TextView(this).apply { text = "MISH UltraVision 0.5 — NVIDIA Shield"; textSize = 26f })
        address = EditText(this).apply { setSingleLine(); setText("http://192.168.1.100:8765"); hint="Windows MISH server" }
        root.addView(address)
        status = TextView(this).apply { text="Укажи IP Windows-компьютера"; textSize=17f }
        root.addView(status)
        root.addView(Button(this).apply { text="Подключиться / обновить"; setOnClickListener { refresh() } })
        files = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; root.addView(files)
    }
    private fun request(path: String, body: JSONObject? = null): String {
        val url = URL(address.text.toString().trim().trimEnd('/') + path)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout=5000; readTimeout=10000
            if(body != null) { requestMethod="POST"; doOutput=true; setRequestProperty("Content-Type","application/json") }
        }
        try {
            if(body != null) conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if(conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally { conn.disconnect() }
    }
    private fun refresh() { thread {
        try { val info=JSONObject(request("/api/status")); val media=JSONArray(request("/api/media"))
            runOnUiThread {
                status.text="${info.optString("name")} · AI: ${info.optBoolean("ai_upscaling")}"; files.removeAllViews()
                for(i in 0 until media.length()) {
                    val name=media.getJSONObject(i).getString("name")
                    files.addView(TextView(this).apply { text=name; textSize=19f })
                    files.addView(Button(this).apply { text="Смотреть"; setOnClickListener { play("/media/"+URLEncoder.encode(name,"UTF-8").replace("+","%20")) } })
                    files.addView(Button(this).apply { text="AI Vulkan: обработать"; setOnClickListener { process(name) } })
                }
                files.addView(Button(this).apply { text="Обновить готовые видео"; setOnClickListener { jobs() } })
            }
        } catch(e: Exception) { runOnUiThread { status.text="Ошибка: ${e.message}" } }
    } }
    private fun process(name: String) { thread { try {
        val response=JSONObject(request("/api/process", JSONObject().put("name",name).put("mode","ai-photo")))
        runOnUiThread { status.text="AI задача ${response.optString("job_id")}. Нажми 'Обновить готовые видео' позже." }
    } catch(e:Exception) { runOnUiThread { status.text="Ошибка: ${e.message}" } } } }
    private fun jobs() { thread { try { val obj=JSONObject(request("/api/jobs"))
        runOnUiThread { files.removeAllViews(); val keys=obj.keys(); while(keys.hasNext()) {
            val key=keys.next(); val job=obj.getJSONObject(key)
            files.addView(TextView(this).apply { text="${job.optString("name")}: ${job.optString("status")}"; textSize=18f })
            if(job.optString("status")=="ready") files.addView(Button(this).apply { text="Смотреть обработанное"; setOnClickListener { play(job.getString("url")) } })
        } }
    } catch(e:Exception) { runOnUiThread { status.text=e.message } } } }
    private fun play(path: String) {
        val url=address.text.toString().trim().trimEnd('/')+path
        player?.release()
        val p=ExoPlayer.Builder(this).build(); player=p
        val view=PlayerView(this).apply { player=p; useController=true }
        setContentView(view); p.setMediaItem(MediaItem.fromUri(url)); p.prepare(); p.playWhenReady=true
    }
    override fun onBackPressed() { if(player!=null) { player?.release(); player=null; onCreate(null) } else super.onBackPressed() }
    override fun onDestroy() { player?.release(); super.onDestroy() }
}
