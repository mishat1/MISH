"""MISH 0.6.1: authenticated LAN streaming and bounded offline processing."""
import argparse
import copy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import queue
import re
import secrets
import threading
from urllib.parse import parse_qs, unquote, urlsplit
import uuid
import ai_backends

MODES = ('clean', 'detail', 'balanced', *ai_backends.MODELS)
EXTS = {'.mp4', '.m4v', '.mov', '.mkv', '.webm'}

def safe_file(root, name):
    if not isinstance(name, str) or not name or name.startswith('.') or '/' in name or '\\' in name:
        return None
    root = Path(root).resolve()
    path = root / name
    try:
        resolved = path.resolve(strict=True)
        return resolved if resolved.is_relative_to(root) and resolved.is_file() and path.suffix.lower() in EXTS else None
    except (OSError, ValueError):
        return None

def byte_range(value, size):
    if value is None:
        return 0, size - 1
    match = re.fullmatch(r'bytes=(\d*)-(\d*)', value)
    if not match or not size:
        raise ValueError('Invalid range')
    first, last = match.groups()
    if not first:
        if not last or int(last) <= 0:
            raise ValueError('Invalid suffix')
        return max(0, size - int(last)), size - 1
    start = int(first)
    end = min(int(last), size - 1) if last else size - 1
    if start >= size or end < start:
        raise ValueError('Unsatisfiable range')
    return start, end

class Application:
    def __init__(self, media, output, token, width=3840, height=2160, verify_ai=False):
        if len(token) < 16:
            raise ValueError('Token must contain at least 16 characters')
        if width % 2 or height % 2 or not (2 <= width <= 3840 and 2 <= height <= 2160):
            raise ValueError('Use even output dimensions, at most 3840x2160')
        self.media, self.output = Path(media).resolve(), Path(output).resolve()
        if self.media == self.output:
            raise ValueError('Media and output must be different directories')
        self.media.mkdir(parents=True, exist_ok=True)
        self.output.mkdir(parents=True, exist_ok=True)
        self.token, self.width, self.height = token, width, height
        self.backend = ai_backends.Backend()
        self.verification = self.backend.verify() if verify_ai else {'note': 'AI verification not requested'}
        self.jobs, self.lock = {}, threading.Lock()
        self.queue = queue.Queue(maxsize=8)
        self.worker = threading.Thread(target=self.work, daemon=True)
        self.worker.start()

    def modes(self):
        basic = ['clean', 'detail', 'balanced'] if self.backend.ffmpeg and self.backend.ffprobe else []
        return basic + list(self.backend.verified)

    def submit(self, name, mode):
        if not safe_file(self.media, name) or not isinstance(mode, str) or mode not in MODES:
            return 400, {'error': 'Invalid name or mode'}
        if mode not in self.modes():
            return 503, {'error': 'Mode unavailable: install dependencies and pass --verify-ai for neural modes'}
        with self.lock:
            if self.queue.full():
                return 429, {'error': 'Queue full (8 waiting jobs)'}
            while len(self.jobs) >= 100:
                terminal = next((k for k, v in self.jobs.items() if v['status'] in {'ready', 'error'}), None)
                if terminal is None:
                    return 429, {'error': 'Too many active jobs'}
                del self.jobs[terminal]
            key = uuid.uuid4().hex
            self.jobs[key] = {'status': 'queued', 'name': name, 'mode': mode}
            self.queue.put_nowait(key)
        return 202, {'job_id': key}

    def work(self):
        while True:
            key = self.queue.get()
            temporary = self.output / ('.' + key + '.partial.mp4')
            destination = self.output / (key + '.mp4')
            try:
                with self.lock:
                    job = self.jobs[key]
                    job['status'] = 'processing'
                    name, mode = job['name'], job['mode']
                source = safe_file(self.media, name)
                if not source:
                    raise ValueError('Source disappeared')
                evidence = self.backend.process(source, temporary, mode, self.width, self.height)
                temporary.rename(destination)
                destination.with_suffix('.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
                with self.lock:
                    self.jobs[key].update(status='ready', url='/processed/' + destination.name, evidence=evidence)
            except Exception as exc:
                temporary.unlink(missing_ok=True)
                destination.unlink(missing_ok=True)
                with self.lock:
                    self.jobs[key].update(status='error', error=str(exc)[:2000])
            finally:
                self.queue.task_done()

def make_server(app, host='127.0.0.1', port=8765):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'

        def setup(self):
            super().setup()
            self.connection.settimeout(15)

        def log_message(self, *_):
            pass  # Never log query tokens.

        def respond(self, status, value=None, headers=None):
            body = json.dumps(value, ensure_ascii=False).encode() if value is not None else b''
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Connection', 'close')
            self.close_connection = True
            for key, value in (headers or {}).items():
                self.send_header(key, value)
            self.end_headers()
            if self.command != 'HEAD':
                self.wfile.write(body)

        def authenticated(self):
            value = parse_qs(urlsplit(self.path).query).get('token', [''])[0]
            header = self.headers.get('Authorization', '')
            if header.startswith('Bearer '):
                value = header[7:]
            if secrets.compare_digest(value.encode(), app.token.encode()):
                return True
            self.respond(401, {'error': 'Unauthorized'})
            return False

        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            if not self.authenticated():
                return
            path = unquote(urlsplit(self.path).path)
            if path == '/api/status':
                return self.respond(200, {'name': 'MISH UltraVision Windows Node', 'version': '0.6.1',
                    'features': ['catalog', 'range-playback', 'offline-processing', 'authenticated'],
                    'ai_upscaling': bool(app.backend.verified), 'modes': app.modes(),
                    'ai_backends': app.backend.status(), 'verification': app.verification,
                    'width': app.width, 'height': app.height})
            if path == '/api/media':
                files = [p for p in sorted(app.media.iterdir()) if safe_file(app.media, p.name)]
                return self.respond(200, [{'name': p.name, 'id': p.name, 'size': p.stat().st_size} for p in files])
            if path == '/api/jobs':
                with app.lock:
                    jobs = copy.deepcopy(app.jobs)
                return self.respond(200, jobs)
            if path.startswith('/media/'):
                return self.serve_file(safe_file(app.media, path[7:]))
            if path.startswith('/processed/'):
                name = path[11:]
                if re.fullmatch(r'[0-9a-f]{32}\.mp4', name):
                    with app.lock:
                        ready = app.jobs.get(name[:-4], {}).get('status') == 'ready'
                    if ready:
                        file = app.output / name
                        if file.resolve().is_relative_to(app.output):
                            return self.serve_file(file)
            return self.respond(404, {'error': 'Not found'})

        def serve_file(self, file):
            if not file or not file.is_file():
                return self.respond(404, {'error': 'File not found'})
            with file.open('rb') as stream:
                size = os.fstat(stream.fileno()).st_size
                value = self.headers.get('Range')
                try:
                    start, end = byte_range(value, size)
                except ValueError:
                    return self.respond(416, {'error': 'Invalid range'}, {'Content-Range': f'bytes */{size}'})
                self.send_response(206 if value is not None else 200)
                self.send_header('Content-Type', mimetypes.guess_type(file.name)[0] or 'application/octet-stream')
                self.send_header('Content-Length', str(max(0, end - start + 1)))
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Cache-Control', 'no-store')
                if value is not None:
                    self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
                self.end_headers()
                if self.command == 'HEAD':
                    return
                stream.seek(start)
                remaining = end - start + 1
                try:
                    while remaining > 0:
                        chunk = stream.read(min(262144, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
                except (BrokenPipeError, ConnectionResetError, TimeoutError):
                    pass

        def do_POST(self):
            if not self.authenticated():
                return
            if urlsplit(self.path).path != '/api/process':
                return self.respond(404, {'error': 'Not found'})
            try:
                if self.headers.get('Transfer-Encoding'):
                    raise ValueError('Chunked requests unsupported')
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 8192:
                    raise ValueError('Invalid request length')
                payload = json.loads(self.rfile.read(length))
                if not isinstance(payload, dict):
                    raise ValueError('JSON object required')
                status, result = app.submit(payload.get('name'), payload.get('mode', 'balanced'))
                return self.respond(status, result)
            except (ValueError, TypeError, UnicodeDecodeError) as exc:
                return self.respond(400, {'error': str(exc)})
    server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True
    return server

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--media', default=str(Path(__file__).parent / 'media'))
    parser.add_argument('--output', default=str(Path(__file__).parent / 'processed'))
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--token-file', default=str(Path(__file__).parent / 'server-token.txt'))
    parser.add_argument('--verify-ai', action='store_true')
    parser.add_argument('--width', type=int, default=3840)
    parser.add_argument('--height', type=int, default=2160)
    args = parser.parse_args()
    token_path = Path(args.token_file)
    if not token_path.exists():
        token_path.write_text(secrets.token_hex(12), encoding='utf-8')
    app = Application(args.media, args.output, token_path.read_text(encoding='utf-8-sig').strip(),
                      args.width, args.height, args.verify_ai)
    server = make_server(app, args.host, args.port)
    print(json.dumps({'port': server.server_port, 'ai_verified': list(app.backend.verified),
                      'token_file': str(token_path)}, ensure_ascii=False), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
