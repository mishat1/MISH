"""Optional real Real-ESRGAN; advertise AI only after successful inference."""
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

MODELS = {'ai-photo': 'realesrgan-x4plus', 'ai-anime': 'realesrgan-x4plus-anime',
          'ai-video': 'realesr-animevideov3'}

def tool(variable, fallback):
    value = os.getenv(variable, fallback)
    path = Path(value)
    return str(path.resolve()) if path.is_file() else shutil.which(value)

def run(command, timeout=14400):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=timeout, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8', errors='replace')[-2000:])
    return result.stdout

def probe(path):
    ffprobe = tool('MISH_FFPROBE', 'ffprobe')
    if not ffprobe:
        raise RuntimeError('ffprobe is required')
    return json.loads(run([ffprobe, '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)], 60))

def video_info(path):
    info = probe(path)
    video = next((s for s in info['streams'] if s['codec_type'] == 'video'), None)
    if not video:
        raise ValueError('No video stream')
    if (video.get('color_transfer') in {'smpte2084', 'arib-std-b67'}
        or video.get('codec_tag_string') in {'dvh1', 'dvhe'}
        or any('dovi' in str(s).lower() or 'dolby vision' in str(s).lower()
               for s in video.get('side_data_list', []))):
        raise ValueError('HDR/Dolby Vision processing is unsupported; use SDR')
    fps = Fraction(video.get('avg_frame_rate', '0/1'))
    if not 0 < fps <= 240:
        raise ValueError('Invalid video frame rate')
    return info, video, fps

class Backend:
    def __init__(self):
        self.ffmpeg = tool('MISH_FFMPEG', 'ffmpeg')
        self.ffprobe = tool('MISH_FFPROBE', 'ffprobe')
        self.engine = tool('MISH_REALESRGAN', 'realesrgan-ncnn-vulkan')
        default = str(Path(self.engine).parent / 'models') if self.engine else 'models'
        self.models_dir = Path(os.getenv('MISH_MODELS_DIR', default)).resolve()
        self.verified = {}

    def model_files(self, model):
        stem = model + '-x4' if model == 'realesr-animevideov3' else model
        return [self.models_dir / (stem + ext) for ext in ['.param', '.bin']]

    def configured(self, model):
        return bool(self.ffmpeg and self.ffprobe and self.engine
                    and all(p.is_file() and p.stat().st_size for p in self.model_files(model)))

    def status(self):
        return {mode: {'configured': self.configured(model), 'verified': mode in self.verified,
                       'model': model, 'evidence': self.verified.get(mode)} for mode, model in MODELS.items()}

    def infer(self, source, output, model):
        if not self.configured(model):
            raise RuntimeError('Real-ESRGAN, model files, ffmpeg and ffprobe required')
        run([self.engine, '-i', str(source), '-o', str(output), '-n', model,
             '-s', '4', '-m', str(self.models_dir), '-f', 'png', '-g', os.getenv('MISH_GPU', '0')])

    def verify(self):
        """Run each real model on a real image; no mocks or executable-presence shortcuts."""
        self.verified = {}
        errors = {}
        with tempfile.TemporaryDirectory(prefix='mish_verify_') as folder:
            folder = Path(folder)
            source = folder / 'input.png'
            if not (self.ffmpeg and self.ffprobe):
                return {'error': 'ffmpeg and ffprobe required'}
            run([self.ffmpeg, '-v', 'error', '-f', 'lavfi', '-i', 'testsrc2=size=32x24',
                 '-frames:v', '1', str(source)])
            for mode, model in MODELS.items():
                try:
                    destination = folder / (mode + '.png')
                    self.infer(source, destination, model)
                    stream = probe(destination)['streams'][0]
                    if (stream.get('width'), stream.get('height')) != (128, 96):
                        raise RuntimeError('Model did not produce expected 4x dimensions')
                    self.verified[mode] = {'input': [32, 24], 'output': [128, 96],
                        'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
                        'engine_sha256': hashlib.sha256(Path(self.engine).read_bytes()).hexdigest(),
                        'weights_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                           for p in self.model_files(model)}}
                except Exception as exc:
                    errors[mode] = str(exc)
        return {'verified': self.verified, 'errors': errors}

    def process(self, source, destination, mode, width=3840, height=2160):
        if not (self.ffmpeg and self.ffprobe):
            raise RuntimeError('ffmpeg and ffprobe required')
        info, video, fps = video_info(source)
        duration = float(info.get('format', {}).get('duration', 0))
        max_seconds = float(os.getenv('MISH_MAX_SECONDS', '600'))
        if not 0 < duration <= max_seconds:
            raise ValueError(f'Input duration must be known and <= {max_seconds} seconds')
        neural = mode in MODELS
        if neural and mode not in self.verified:
            raise RuntimeError('AI model has not passed startup inference verification')
        if not neural and mode not in {'clean', 'detail', 'balanced'}:
            raise ValueError('Unknown processing mode')
        scale = (f'scale={width}:{height}:force_original_aspect_ratio=decrease:'
                 f'force_divisible_by=2:flags=lanczos,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1')
        with tempfile.TemporaryDirectory(prefix='mish_process_') as folder:
            folder = Path(folder)
            inputs = ['-i', str(source)]
            maps = ['-map', '0:v:0', '-map', '0:a:0?']
            filters = {'clean': 'hqdn3d=1.5:1.5:6:6,' + scale,
                       'detail': scale + ',unsharp=5:5:0.45:3:3:0.15',
                       'balanced': 'hqdn3d=1:1:3:3,' + scale + ',unsharp=5:5:0.25:3:3:0'}
            vf = filters.get(mode, scale)
            if neural:
                count_bound = int(duration * float(fps)) + 2
                if video['width'] * video['height'] > 1920 * 1080 or count_bound > 18000:
                    raise ValueError('AI input limited to 1080p and 18000 frames; split long videos')
                required = count_bound * video['width'] * video['height'] * 4 * 17
                if shutil.disk_usage(folder).free < required + 512 * 1024**2:
                    raise ValueError('Insufficient temporary disk space for neural frames')
                frames, result = folder / 'input', folder / 'output'
                frames.mkdir(); result.mkdir()
                # Convert VFR to explicit CFR before extraction and use the same rate on reassembly.
                run([self.ffmpeg, '-v', 'error', '-nostdin', '-i', str(source),
                     '-map', '0:v:0', '-vf', f'fps={fps}', str(frames / '%08d.png')])
                names = sorted(p.name for p in frames.glob('*.png'))
                if not names:
                    raise RuntimeError('No frames extracted')
                self.infer(frames, result, MODELS[mode])
                if names != sorted(p.name for p in result.glob('*.png')):
                    raise RuntimeError('Neural output frames are missing or unexpected')
                inputs = ['-framerate', str(fps), '-i', str(result / '%08d.png'), '-i', str(source)]
                maps = ['-map', '0:v:0', '-map', '1:a:0?']
            run([self.ffmpeg, '-v', 'error', '-nostdin', '-n', *inputs, *maps, '-vf', vf,
                 '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p',
                 '-c:a', 'aac', '-ac', '2', '-b:a', '192k', '-t', str(duration),
                 '-movflags', '+faststart', str(destination)])
            result_video = next(s for s in probe(destination)['streams'] if s['codec_type'] == 'video')
            if (result_video['width'], result_video['height']) != (width, height):
                raise RuntimeError('Encoded resolution mismatch')
            run([self.ffmpeg, '-v', 'error', '-nostdin', '-i', str(destination), '-f', 'null', '-'])
        return {'neural': neural, 'model': MODELS.get(mode), 'mode': mode,
                'width': width, 'height': height, 'fps': str(fps), 'duration': duration,
                'audio': 'first track, AAC stereo', 'color': 'SDR only',
                'verification': self.verified.get(mode)}
