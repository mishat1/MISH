"""Named, explicitly shared directories; never scans the whole computer."""
import hashlib
import json
from pathlib import Path, PurePosixPath

EXTS = {'.mp4', '.m4v', '.mov', '.mkv', '.webm'}

def safe_file(root, name):
    if not isinstance(name, str) or not name or '\\' in name or ':' in name:
        return None
    parts = PurePosixPath(name).parts
    if name.startswith('/') or not parts or any(p.startswith('.') for p in parts):
        return None
    try:
        root = Path(root).resolve()
        path = (root / name).resolve(strict=True)
        return path if path.is_relative_to(root) and path.is_file() and path.suffix.lower() in EXTS else None
    except (OSError, ValueError):
        return None

class Library:
    def __init__(self, root, config=None):
        self.sources = [{'id': 'library', 'title': 'Моя медиатека', 'root': Path(root).resolve()}]
        if config:
            data = json.loads(Path(config).read_text(encoding='utf-8-sig'))
            for entry in data.get('sources', []):
                folder = Path(entry['path']).expanduser().resolve(strict=True)
                if not folder.is_dir():
                    raise ValueError('Shared source must be a directory')
                key = hashlib.sha256(str(folder).encode()).hexdigest()[:12]
                if any(s['root'] == folder for s in self.sources):
                    continue
                self.sources.append({'id': key, 'title': str(entry['title'])[:80], 'root': folder})

    def resolve(self, name):
        if not isinstance(name, str):
            return None
        if name.startswith('@'):
            key, separator, relative = name[1:].partition('/')
            source = next((s for s in self.sources if s['id'] == key), None)
            return safe_file(source['root'], relative) if source and separator else None
        return safe_file(self.sources[0]['root'], name)

    def catalog(self):
        items = []
        for source in self.sources:
            for path in sorted(source['root'].rglob('*')):
                if not path.is_file() or path.suffix.lower() not in EXTS:
                    continue
                relative = path.relative_to(source['root']).as_posix()
                if not safe_file(source['root'], relative):
                    continue
                key = relative if source['id'] == 'library' else '@' + source['id'] + '/' + relative
                folder = str(PurePosixPath(relative).parent)
                items.append({'name': key, 'id': key, 'size': path.stat().st_size,
                              'title': path.stem, 'folder': '' if folder == '.' else folder,
                              'source': source['id'], 'filename': path.name})
        return items

    def public_sources(self, catalog):
        return [{'id': s['id'], 'title': s['title'],
                 'count': sum(i['source'] == s['id'] for i in catalog)} for s in self.sources]
