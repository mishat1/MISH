"""Optional Bonjour advertisement. Run alongside server.py: python bonjour_optional.py"""
import os, socket, time
from zeroconf import IPVersion, ServiceInfo, Zeroconf

name = socket.gethostname()
ips = []
try:
    for item in socket.getaddrinfo(name, None, socket.AF_INET):
        ip = item[4][0]
        if not ip.startswith('127.') and ip not in ips: ips.append(ip)
except OSError: pass
if not ips:
    raise SystemExit('No LAN IPv4 found; use manual IP on Apple TV')
info = ServiceInfo('_mishvision._tcp.local.', f'MISH-{name}._mishvision._tcp.local.',
                   addresses=[socket.inet_aton(ips[0])], port=int(os.getenv('MISH_PORT', '8765')),
                   properties={'version':'0.6.1'}, server=f'{name}.local.')
z = Zeroconf(ip_version=IPVersion.V4Only)
try:
    z.register_service(info)
    print('Bonjour advertisement:', name, ips[0]); print('Press Ctrl+C to stop')
    while True: time.sleep(1)
except KeyboardInterrupt: pass
finally: z.unregister_service(info); z.close()
