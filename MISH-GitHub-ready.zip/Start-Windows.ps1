param(
    [string]$Media = '',
    [string]$BindAddress = '0.0.0.0',
    [int]$Port = 8765,
    [switch]$VerifyAI
)
$ErrorActionPreference = 'Stop'
if (-not $Media) { $Media = Join-Path $PSScriptRoot 'Windows_Server/media' }
$definitions = @(
    @{ Name = 'MISH_FFMPEG'; File = 'ffmpeg.exe' },
    @{ Name = 'MISH_FFPROBE'; File = 'ffprobe.exe' },
    @{ Name = 'MISH_REALESRGAN'; File = 'realesrgan-ncnn-vulkan.exe' }
)
$toolsRoot = Join-Path $PSScriptRoot 'tools'
if (Test-Path -LiteralPath $toolsRoot) {
    foreach ($definition in $definitions) {
        $found = Get-ChildItem -LiteralPath $toolsRoot -Recurse -File -Filter $definition.File | Select-Object -First 1
        if ($found) { [Environment]::SetEnvironmentVariable($definition.Name, $found.FullName, 'Process') }
    }
}
$tokenPath = Join-Path $PSScriptRoot 'Windows_Server/server-token.txt'
if (-not (Test-Path -LiteralPath $tokenPath)) {
    $bytes = New-Object byte[] 12
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    $rng.GetBytes($bytes)
    $rng.Dispose()
    ([BitConverter]::ToString($bytes)).Replace('-', '').ToLowerInvariant() | Set-Content -LiteralPath $tokenPath -Encoding ascii
}
Write-Host 'Token for Apple TV (keep private):'
Get-Content -LiteralPath $tokenPath
$serverArguments = @((Join-Path $PSScriptRoot 'Windows_Server/server.py'), '--media', $Media,
    '--host', $BindAddress, '--port', "$Port", '--token-file', $tokenPath)
if ($VerifyAI) { $serverArguments += '--verify-ai' }
python @serverArguments
