"""Integration tests use real FFmpeg and all three real Vulkan models, never mocks."""
import hashlib
import http.client
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Windows_Server'))
import ai_backends
from server import Application, safe_file

class Integration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ffmpeg = ai_backends.tool('MISH_FFMPEG', 'ffmpeg')
        if not cls.ffmpeg:
            raise RuntimeError('Real FFmpeg required for integration tests')
        cls.folder = tempfile.TemporaryDirectory(prefix='mish_e2e_')
        cls.root = Path(cls.folder.name)
        cls.media, cls.output = cls.root / 'media', cls.root / 'processed'
        cls.media.mkdir(); cls.output.mkdir()
        cls.filename = 'Тест #1 +.mp4'
        cls.source = cls.media / cls.filename
        ai_backends.run([cls.ffmpeg, '-v', 'error', '-nostdin', '-f', 'lavfi', '-i',
            'testsrc2=size=64x36:rate=6', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000',
            '-t', '1', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-movflags',
            '+faststart', str(cls.source)])
        cls.token = 'integration+token/?&characters'
        (cls.root / 'token.txt').write_text(cls.token, encoding='utf-8')
        cls.process = subprocess.Popen([sys.executable, '-u', str(ROOT / 'Windows_Server' / 'server.py'),
            '--media', str(cls.media), '--output', str(cls.output), '--token-file', str(cls.root / 'token.txt'),
            '--port', '0', '--width', '256', '--height', '144', '--verify-ai'],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        first = cls.process.stdout.readline()
        if not first:
            raise RuntimeError(cls.process.stderr.read())
        cls.startup = json.loads(first)
        cls.port = cls.startup['port']

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate()
        cls.process.communicate(timeout=10)
        cls.folder.cleanup()

    def request(self, path, method='GET', payload=None, auth=True, headers=None):
        if auth:
            path += '?token=' + quote(self.token, safe='')
        body = json.dumps(payload).encode() if payload is not None else None
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=15)
        connection.request(method, path, body=body, headers=headers or {})
        response = connection.getresponse()
        result = response.status, dict(response.getheaders()), response.read()
        connection.close()
        return result

    def submit_and_wait(self, mode):
        status, _, body = self.request('/api/process', 'POST', {'name': self.filename, 'mode': mode})
        self.assertEqual(status, 202, body)
        key = json.loads(body)['job_id']
        deadline = time.monotonic() + 180
        while time.monotonic() < deadline:
            _, _, body = self.request('/api/jobs')
            job = json.loads(body)[key]
            if job['status'] in {'ready', 'error'}:
                self.assertEqual(job['status'], 'ready', job)
                return job
            time.sleep(.2)
        self.fail('Processing timed out')

    def check_video(self, job, neural):
        status, _, body = self.request(job['url'])
        self.assertEqual(status, 200)
        file = self.root / (job['mode'] + '-download.mp4')
        file.write_bytes(body)
        info = ai_backends.probe(file)
        video = next(s for s in info['streams'] if s['codec_type'] == 'video')
        audio = next(s for s in info['streams'] if s['codec_type'] == 'audio')
        self.assertEqual((video['width'], video['height']), (256, 144))
        self.assertEqual(video['codec_name'], 'h264')
        self.assertEqual(audio['codec_name'], 'aac')
        self.assertAlmostEqual(float(info['format']['duration']), 1, delta=.12)
        self.assertEqual(int(video['nb_frames']), 6)
        self.assertEqual(job['evidence']['neural'], neural)
        url = f'http://127.0.0.1:{self.port}' + job['url'] + '?token=' + quote(self.token, safe='')
        ai_backends.run([self.ffmpeg, '-v', 'error', '-nostdin', '-ss', '0.5', '-i', url, '-f', 'null', '-'], 30)
        # Optional export keeps evidence and playable samples, excluding credentials.
        export = os.getenv('MISH_TEST_EXPORT')
        if export:
            export = Path(export)
            export.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(file, export / file.name)
            shutil.copyfile(self.source, export / 'input-64x36.mp4')
            (export / (job['mode'] + '.json')).write_text(json.dumps(job, indent=2, ensure_ascii=False), encoding='utf-8')

    def test_01_capabilities_require_real_inference(self):
        self.assertEqual(set(self.startup['ai_verified']), set(ai_backends.MODELS))
        status, _, body = self.request('/api/status')
        self.assertEqual(status, 200)
        data = json.loads(body)
        self.assertTrue(data['ai_upscaling'])
        for mode in ai_backends.MODELS:
            self.assertTrue(data['ai_backends'][mode]['verified'])
            self.assertEqual(data['ai_backends'][mode]['evidence']['output'], [128, 96])

    def test_02_auth_catalog_filename(self):
        self.assertEqual(self.request('/api/media', auth=False)[0], 401)
        status, _, body = self.request('/api/media')
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)[0]['name'], self.filename)
        self.assertEqual(self.request('/api/media', auth=False,
            headers={'Authorization': 'Bearer ' + self.token})[0], 200)

    def test_03_range_integrity_head(self):
        path = '/media/' + quote(self.filename, safe='')
        status, headers, body = self.request(path)
        self.assertEqual(status, 200)
        self.assertEqual(hashlib.sha256(body).digest(), hashlib.sha256(self.source.read_bytes()).digest())
        data = body
        for value, expected in [('bytes=0-99', data[:100]), ('bytes=100-', data[100:]), ('bytes=-64', data[-64:])]:
            status, headers, body = self.request(path, headers={'Range': value})
            self.assertEqual(status, 206)
            self.assertEqual(body, expected)
            self.assertIn('Content-Range', headers)
        status, headers, body = self.request(path, method='HEAD')
        self.assertEqual(status, 200)
        self.assertEqual(body, b'')
        self.assertEqual(int(headers['Content-Length']), len(data))

    def test_04_invalid_ranges_and_paths(self):
        path = '/media/' + quote(self.filename, safe='')
        for value in ['bytes=-0', 'bytes=999999999-', 'bytes=2-1', 'bytes=0-1,3-4', 'bytes=-']:
            status, headers, _ = self.request(path, headers={'Range': value})
            self.assertEqual(status, 416)
            self.assertIn('Content-Range', headers)
        for path in ['/media/../token.txt', '/media/%2e%2e/token.txt', '/processed/' + 'a'*32 + '.mp4']:
            self.assertEqual(self.request(path)[0], 404)

    def test_05_invalid_json_and_mode(self):
        for payload in [[], 'bad', {'name': None}, {'name': ['x']}, {'name': self.filename, 'mode': []},
                        {'name': self.filename, 'mode': 'fake-ai'}]:
            self.assertEqual(self.request('/api/process', 'POST', payload)[0], 400)

    def test_06_basic_pipeline(self):
        for mode in ['balanced', 'clean', 'detail']:
            with self.subTest(mode=mode):
                self.check_video(self.submit_and_wait(mode), False)

    def test_07_neural_pipeline_all_models(self):
        for mode in ai_backends.MODELS:
            with self.subTest(mode=mode):
                self.check_video(self.submit_and_wait(mode), True)

    def test_08_symlink_escape(self):
        external = self.root / 'secret.mp4'
        external.write_bytes(b'secret')
        link = self.media / 'escape.mp4'
        try:
            link.symlink_to(external)
        except OSError:
            self.skipTest('Windows symlink privilege unavailable')
        try:
            self.assertIsNone(safe_file(self.media, 'escape.mp4'))
            self.assertEqual(self.request('/media/escape.mp4')[0], 404)
        finally:
            link.unlink()

    def test_09_unverified_ai_is_disabled(self):
        backend = ai_backends.Backend()
        self.assertEqual(backend.verified, {})
        for value in backend.status().values():
            self.assertFalse(value['verified'])
        with self.assertRaisesRegex(RuntimeError, 'verification'):
            backend.process(self.source, self.root / 'unverified.mp4', 'ai-photo', 256, 144)

    def test_10_hdr_rejected(self):
        hdr = self.root / 'hdr.mp4'
        ai_backends.run([self.ffmpeg, '-v', 'error', '-nostdin', '-i', str(self.source),
            '-vf', 'setparams=color_trc=smpte2084:color_primaries=bt2020:colorspace=bt2020nc',
            '-c:v', 'libx264', '-c:a', 'copy', str(hdr)])
        with self.assertRaisesRegex(ValueError, 'HDR'):
            ai_backends.video_info(hdr)

if __name__ == '__main__':
    unittest.main(verbosity=2)
