"""Real HTTP folder/thumbnail/dashboard checks; no model mocks."""
import http.client
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import threading
import unittest
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'Windows_Server'))
from server import Application, make_server
from library import Library, safe_file

class LibraryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        parent = Path(os.getenv('MISH_TEST_TMPDIR', str(Path(__file__).resolve().parents[1] / 'test-work')))
        parent.mkdir(parents=True, exist_ok=True)
        cls.temp = tempfile.TemporaryDirectory(dir=parent)
        cls.root = Path(cls.temp.name)
        cls.media = cls.root / 'media'
        cls.nested = cls.media / 'Фильмы'
        cls.nested.mkdir(parents=True)
        cls.original = Path(__file__).resolve().parents[1] / 'verified-samples/input-64x36.mp4'
        shutil.copyfile(cls.original, cls.nested / 'Тест #1.mp4')
        cls.other = cls.root / 'other'
        cls.other.mkdir()
        shutil.copyfile(cls.original, cls.other / 'Другой.mp4')
        config = cls.root / 'sources.json'
        config.write_text(json.dumps({'sources':[{'title':'Внешний диск','path':str(cls.other)}]}), encoding='utf-8')
        cls.token = 'library+token/test?private'
        cls.app = Application(cls.media, cls.root / 'output', cls.token, 256, 144, sources_file=config)
        cls.server = make_server(cls.app, port=0)
        cls.worker = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.worker.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.worker.join()
        cls.temp.cleanup()

    def request(self, path, auth=True):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=30)
        connection.request('GET', path + ('?token='+quote(self.token,safe='') if auth else ''))
        response = connection.getresponse()
        result = response.status, dict(response.getheaders()), response.read()
        connection.close()
        return result

    def test_nested_and_multiple_sources(self):
        status, _, body = self.request('/api/media')
        self.assertEqual(status,200)
        items=json.loads(body)
        self.assertEqual(len(items),2)
        nested=next(f for f in items if f['folder']=='Фильмы')
        self.assertEqual(nested['title'],'Тест #1')
        for item in items:
            status, _, data=self.request('/media/'+quote(item['name'],safe=''))
            self.assertEqual(status,200)
            self.assertEqual(data,self.original.read_bytes())
        _, _, body=self.request('/api/sources')
        sources=json.loads(body)
        self.assertEqual([s['count'] for s in sources],[1,1])
        self.assertNotIn(str(self.root),body.decode())

    def test_traversal_and_hidden_excluded(self):
        for name in ['../other/Другой.mp4','Фильмы/../../other/Другой.mp4','C:/file.mp4','Фильмы\\file.mp4']:
            self.assertIsNone(safe_file(self.media,name))
        hidden=self.media/'.hidden.mp4'
        hidden.write_bytes(b'secret')
        try:
            _,_,body=self.request('/api/media')
            self.assertNotIn('.hidden.mp4',body.decode())
        finally: hidden.unlink()

    def test_dashboard_and_auth(self):
        status,headers,body=self.request('/',auth=False)
        self.assertEqual(status,200)
        self.assertIn('text/html',headers['Content-Type'])
        self.assertIn('Мои фильмы',body.decode())
        self.assertNotIn(self.token,body.decode())
        self.assertEqual(self.request('/api/sources',auth=False)[0],401)

    def test_thumbnail_from_real_video(self):
        self.assertIsNotNone(self.app.backend.ffmpeg,'Set MISH_FFMPEG for the thumbnail test')
        path='/thumb/'+quote('Фильмы/Тест #1.mp4',safe='')
        status,headers,body=self.request(path)
        self.assertEqual(status,200)
        self.assertEqual(headers['Content-Type'],'image/jpeg')
        self.assertTrue(body.startswith(b'\xff\xd8'))
        self.assertEqual(self.request(path)[2],body)
        self.assertEqual(self.request(path,auth=False)[0],401)

if __name__ == '__main__': unittest.main(verbosity=2)
